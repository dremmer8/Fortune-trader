// Main initialization and game loop

// ===========================================
// HUB / PHONE INTERFACE
// ===========================================

let gameStarted = false;
let isLoggedIn = false;
let playerName = '';
let playerId = '';
let bankerMode = 'deposit';

// ===========================================
// VERSION STAMP
// ===========================================

function getVersionStamp() {
    if (typeof APP_VERSION === 'string' && APP_VERSION.trim()) {
        return APP_VERSION.trim();
    }
    return 'v0.0.0';
}

function updateVersionStamp() {
    const versionText = getVersionStamp();
    const stamp = document.getElementById('versionStamp');
    if (stamp) {
        stamp.textContent = versionText;
    }

    const settingsVersion = document.getElementById('settingsVersionValue');
    if (settingsVersion) {
        settingsVersion.textContent = `Version ${versionText}`;
    }
}

function initVersionStamp() {
    updateVersionStamp();
    window.addEventListener('app-version-ready', updateVersionStamp);
}

function initAudioControls() {
    const slider = document.getElementById('audioVolumeSlider');
    const valueLabel = document.getElementById('audioVolumeValue');
    if (!slider || !valueLabel || typeof AudioManager === 'undefined') return;

    const updateLabel = (value) => {
        valueLabel.textContent = `${value}%`;
    };

    const initialValue = Math.round((AudioManager.masterVolume ?? 0.8) * 100);
    slider.value = String(initialValue);
    updateLabel(initialValue);

    slider.addEventListener('input', (event) => {
        const value = Number(event.target.value);
        AudioManager.setMasterVolume(value / 100);
        updateLabel(value);
    });
}

function initButtonClickSounds() {
    document.addEventListener('click', (event) => {
        const button = event.target.closest('button');
        if (!button) return;
        if (button.disabled || button.getAttribute('aria-disabled') === 'true') return;
        if (button.dataset.clickSound === 'manual') return;
        if (typeof AudioManager === 'undefined') return;
        AudioManager.playClick();
    });
}

// ===========================================
// LOGIN CARD INTERFACE
// ===========================================

function normalizePlayerName(name) {
    return (name || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

// Initialize login card events
function initLoginCard() {
    const nameInput = document.getElementById('cardHolderInput');
    const cvvInput = document.getElementById('cardCvvInput');
    const nextBtn = document.getElementById('cardNextBtn');
    const loginBtn = document.getElementById('cardLoginBtn');
    
    if (nameInput) {
        nameInput.addEventListener('input', (e) => {
            const value = e.target.value.trim();
            if (nextBtn) {
                nextBtn.classList.toggle('active', value.length >= 2);
            }
        });
        
        nameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.target.value.trim().length >= 2) {
                flipCardToBack();
            }
        });
    }
    
    if (cvvInput) {
        cvvInput.addEventListener('input', (e) => {
            const value = e.target.value.trim();
            if (loginBtn) {
                loginBtn.classList.toggle('active', value.length >= 3);
            }
        });
        
        cvvInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.target.value.trim().length >= 3) {
                attemptLogin();
            }
        });
    }
}

// Flip card to back (after entering name)
function flipCardToBack() {
    const nameInput = document.getElementById('cardHolderInput');
    const cardWrapper = document.getElementById('cardWrapper');
    const signatureDisplay = document.getElementById('signatureDisplay');
    
    if (!nameInput || nameInput.value.trim().length < 2) return;
    
    // Play click sound
    AudioManager.playClick();
    
    playerName = nameInput.value.trim().replace(/\s+/g, ' ');
    
    // Update signature on back
    if (signatureDisplay) {
        signatureDisplay.textContent = playerName;
    }
    
    // Flip card
    if (cardWrapper) {
        cardWrapper.classList.add('flipped');
    }
    
    // Focus CVV input after flip
    setTimeout(() => {
        const cvvInput = document.getElementById('cardCvvInput');
        if (cvvInput) cvvInput.focus();
    }, 600);
}

// Flip card back to front
function flipCardToFront() {
    const cardWrapper = document.getElementById('cardWrapper');
    if (cardWrapper) {
        cardWrapper.classList.remove('flipped');
    }
    
    // Focus name input after flip
    setTimeout(() => {
        const nameInput = document.getElementById('cardHolderInput');
        if (nameInput) nameInput.focus();
    }, 600);
}

// Attempt to login (singleplayer mode - simplified)
async function attemptLogin() {
    const cvvInput = document.getElementById('cardCvvInput');
    const nameInput = document.getElementById('cardHolderInput');
    
    // Get player name (use input value or default)
    const trimmedName = (nameInput?.value.trim() || playerName || 'Player').trim().replace(/\s+/g, ' ');
    playerName = trimmedName;
    
    // Generate a simple user ID based on name (no password needed in singleplayer)
    const nameKey = normalizePlayerName(trimmedName);
    playerId = `sp_${nameKey}_${Date.now()}`;
    isLoggedIn = true;
    
    // Play success sound
    AudioManager.playClick();
    
    // Save credentials to localStorage
    saveCredentials();
    
    // Load game state from localStorage
    await loadGameState();
    
    // Hide login card
    const loginContainer = document.getElementById('loginCardContainer');
    if (loginContainer) {
        loginContainer.classList.add('hidden');
    }
    
    // Start expense system after login
    initExpenseSystem();
    initLoanSystem();
    
    // Check for game over condition after loading state
    checkGameOver();
    
    // Update any displays that show player name
    updatePlayerDisplay();
    
    console.log(`Playing as: ${playerName} (Singleplayer Mode)`);
}

// Save credentials to localStorage
function saveCredentials() {
    try {
        const credentials = {
            playerName: playerName,
            playerId: playerId
        };
        localStorage.setItem('fortuneTraderCredentials', JSON.stringify(credentials));
    } catch (e) {
        console.error('Failed to save credentials:', e);
    }
}

// Load credentials from localStorage
function loadCredentials() {
    try {
        const saved = localStorage.getItem('fortuneTraderCredentials');
        if (saved) {
            const credentials = JSON.parse(saved);
            if (credentials.playerName) {
                return credentials;
            }
        }
    } catch (e) {
        console.error('Failed to load credentials:', e);
    }
    return null;
}

// Clear saved credentials
function clearCredentials() {
    try {
        localStorage.removeItem('fortuneTraderCredentials');
    } catch (e) {
        console.error('Failed to clear credentials:', e);
    }
}

// Shake login card on error
function shakeLogin() {
    const container = document.getElementById('loginCardContainer');
    if (container) {
        container.classList.add('shake');
        setTimeout(() => container.classList.remove('shake'), 400);
    }
}

// Update displays with player name
function updatePlayerDisplay() {
    // Could add player name display in banker app header, etc.
}

// Show login card (on fresh start or reset)
function showLoginCard() {
    isLoggedIn = false;
    playerName = '';
    playerId = '';
    
    const loginContainer = document.getElementById('loginCardContainer');
    const cardWrapper = document.getElementById('cardWrapper');
    const nameInput = document.getElementById('cardHolderInput');
    const cvvInput = document.getElementById('cardCvvInput');
    const nextBtn = document.getElementById('cardNextBtn');
    const loginBtn = document.getElementById('cardLoginBtn');
    
    // Reset card state
    if (cardWrapper) cardWrapper.classList.remove('flipped');
    if (nameInput) nameInput.value = '';
    if (cvvInput) cvvInput.value = '';
    if (nextBtn) nextBtn.classList.remove('active');
    if (loginBtn) loginBtn.classList.remove('active');
    
    // Show login
    if (loginContainer) {
        loginContainer.classList.remove('hidden');
    }
    
    // Focus name input
    setTimeout(() => {
        if (nameInput) nameInput.focus();
    }, 300);
}

// Update phone time display
function updatePhoneTime() {
    const phoneTimeEl = document.getElementById('phoneTime');
    if (phoneTimeEl) {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        phoneTimeEl.textContent = `${hours}:${minutes}`;
    }
}

// Launch an app from the phone
function launchApp(appName) {
    // Must be logged in first (except for settings)
    if (!isLoggedIn && appName !== 'settings' && appName !== 'expenses' && appName !== 'leaderboard') {
        showLoginCard();
        return;
    }
    
    // Expenses app shows different view when not logged in
    if (appName === 'expenses' && !isLoggedIn) {
        showLoginCard();
        return;
    }
    
    if (appName === 'trader') {
        // Check if user has trading funds
        if (!hasTradingFunds()) {
            // Show locked overlay
            const lockedOverlay = document.getElementById('traderLockedOverlay');
            if (lockedOverlay) {
                lockedOverlay.classList.add('visible');
            }
            AudioManager.playError();
            return;
        }
        
        // Play trader app open sound
        AudioManager.playOpenTrader();
        
        // Add launch animation
        const traderApp = document.querySelector('.phone-app:first-child');
        if (traderApp) {
            traderApp.classList.add('launching');
        }
        
        // Delay game start for animation
        setTimeout(() => {
            startGame();
        }, 400);
    } else if (appName === 'banker') {
        AudioManager.playOpenApp();
        openBankerApp();
    } else if (appName === 'shop') {
        AudioManager.playOpenApp();
        openShopApp();
    } else if (appName === 'expenses') {
        AudioManager.playOpenApp();
        openExpensesApp();
    } else if (appName === 'leaderboard') {
        AudioManager.playOpenApp();
        openLeaderboardApp();
    } else if (appName === 'settings') {
        AudioManager.playOpenApp();
        openSettingsApp();
    }
}

// Open banker app
function openBankerApp() {
    const overlay = document.getElementById('bankerAppOverlay');
    if (overlay) {
        overlay.classList.add('visible');
        updateBankerDisplay();
        setBankerMode(bankerMode);
    }
}

// Close banker app
function closeBankerApp() {
    const overlay = document.getElementById('bankerAppOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
    updateTraderLockState();
}

function setBankerMode(mode) {
    bankerMode = mode === 'loan' ? 'loan' : 'deposit';

    const buttons = document.querySelectorAll('.banker-mode-btn');
    buttons.forEach(button => {
        const isActive = button.dataset.mode === bankerMode;
        button.classList.toggle('active', isActive);
    });

    const depositSection = document.getElementById('bankerDepositSection');
    if (depositSection) {
        depositSection.classList.toggle('active', bankerMode === 'deposit');
    }

    const loanSection = document.getElementById('bankerLoanSection');
    if (loanSection) {
        loanSection.classList.toggle('active', bankerMode === 'loan');
    }

    if (bankerMode === 'loan') {
        renderLoanOptions();
        updateLoanDisplay();
    }
}

// Open settings app
function openSettingsApp() {
    const overlay = document.getElementById('settingsAppOverlay');
    if (overlay) {
        overlay.classList.add('visible');
        updateSettingsDisplay();
    }
}

// Close settings app
function closeSettingsApp() {
    const overlay = document.getElementById('settingsAppOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
}

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value ?? '';
    return div.innerHTML;
}

function formatCompactNumber(value) {
    const number = Math.floor(Number(value) || 0);
    const absValue = Math.abs(number);
    if (absValue >= 1_000_000_000) {
        return `${Math.floor(number / 1_000_000_000)}B`;
    }
    if (absValue >= 1_000_000) {
        return `${Math.floor(number / 1_000_000)}M`;
    }
    if (absValue >= 1_000) {
        return `${Math.floor(number / 1_000)}K`;
    }
    return number.toLocaleString();
}

// Update settings display
function updateSettingsDisplay() {
    const userNameEl = document.getElementById('settingsUserName');
    if (userNameEl) {
        userNameEl.textContent = playerName || 'Not logged in';
    }
}

// Logout function - clears credentials and shows login card
function logout() {
    // Clear saved credentials
    clearCredentials();
    
    // Reset login state
    isLoggedIn = false;
    playerName = '';
    playerId = '';
    
    // Close settings menu
    closeSettingsApp();
    
    // Show login card
    showLoginCard();
    
    // Play click sound
    if (typeof AudioManager !== 'undefined') {
        AudioManager.playClick();
    }
    
    console.log('Logged out successfully');
}

// ===========================================
// LEADERBOARD APP
// ===========================================

async function openLeaderboardApp() {
    const overlay = document.getElementById('leaderboardAppOverlay');
    if (overlay) {
        overlay.classList.add('visible');
    }
    await loadLeaderboard();
}

function closeLeaderboardApp() {
    const overlay = document.getElementById('leaderboardAppOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
}

async function loadLeaderboard() {
    const statusEl = document.getElementById('leaderboardStatus');
    const listEl = document.getElementById('leaderboardList');
    const updatedEl = document.getElementById('leaderboardUpdated');

    if (statusEl) {
        statusEl.textContent = 'Leaderboard is not available in singleplayer mode.';
        statusEl.style.display = 'block';
    }
    if (listEl) {
        listEl.innerHTML = '<div class="leaderboard-card" style="text-align: center; padding: 2rem;"><p>Play the online version to compete on the global leaderboard!</p></div>';
    }
    if (updatedEl) {
        updatedEl.textContent = '';
    }
}

// Derive a stable user ID from name + password without storing the password
async function deriveUserId(name, password) {
    const base = `${name}:${password}`;
    if (window.crypto && window.crypto.subtle) {
        const data = new TextEncoder().encode(base);
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(hashBuffer))
            .map(byte => byte.toString(16).padStart(2, '0'))
            .join('');
    }
    return btoa(unescape(encodeURIComponent(base))).replace(/=+$/, '');
}

// Switch to banker from locked overlay
function switchToBanker() {
    const lockedOverlay = document.getElementById('traderLockedOverlay');
    if (lockedOverlay) {
        lockedOverlay.classList.remove('visible');
    }
    openBankerApp();
}

// Close trader locked overlay
function closeTraderLocked() {
    const overlay = document.getElementById('traderLockedOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
}

// Update banker display
function updateBankerDisplay() {
    const bankBalanceEl = document.getElementById('bankBalanceDisplay');
    const lifetimeEl = document.getElementById('lifetimeEarnings');
    const spendingsEl = document.getElementById('lifetimeSpendings');
    const tradingBalanceEl = document.getElementById('tradingAccountBalance');
    const userNameEl = document.getElementById('bankerUserName');
    
    if (bankBalanceEl) bankBalanceEl.textContent = '$' + Math.floor(state.bankBalance).toLocaleString();
    if (lifetimeEl) lifetimeEl.textContent = '$' + Math.floor(state.totalEarnings).toLocaleString();
    if (spendingsEl) spendingsEl.textContent = '$' + Math.floor(state.lifetimeSpendings || 0).toLocaleString();
    if (tradingBalanceEl) {
        const portfolioValue = getTotalPortfolioValue();
        tradingBalanceEl.textContent = '$' + Math.floor(portfolioValue).toLocaleString();
    }
    if (userNameEl && playerName) {
        userNameEl.textContent = playerName;
    }

    updateLoanDisplay();
    updateEarningsHistoryPanel();
    updateSpendingHistoryPanel();
}

function addSpendingEntry({ amount, type, label, timestamp = Date.now() }) {
    if (!amount || amount <= 0) return;
    if (!state.spendingHistory) {
        state.spendingHistory = [];
    }

    state.lifetimeSpendings = (state.lifetimeSpendings || 0) + amount;
    state.spendingHistory.push({
        amount,
        type,
        label,
        timestamp
    });
}

function addEarningsEntry({ roundNumber, amountAfterFee, fee, netProfit, initialDeposit, timestamp = Date.now() }) {
    if (!state.earningsHistory) {
        state.earningsHistory = [];
    }

    state.earningsHistory.push({
        roundNumber,
        amountAfterFee,
        fee,
        netProfit,
        initialDeposit,
        timestamp
    });
}

function updateEarningsHistoryPanel() {
    const listEl = document.getElementById('earningsHistoryList');
    if (!listEl) return;

    const history = (state.earningsHistory || []).slice().sort((a, b) => a.timestamp - b.timestamp);
    if (history.length === 0) {
        listEl.innerHTML = '<div class="earnings-entry-empty">No rounds cashed out yet.</div>';
        return;
    }

    listEl.innerHTML = history.map(entry => {
        const dateLabel = new Date(entry.timestamp).toLocaleString();
        const netProfit = Math.round(entry.netProfit || 0);
        const profitPrefix = netProfit >= 0 ? '+$' : '-$';
        const amountLabel = `${profitPrefix}${Math.abs(netProfit).toLocaleString()}`;
        const amountClass = netProfit >= 0 ? 'positive' : 'negative';
        const detailParts = [];

        if (typeof entry.initialDeposit === 'number') {
            detailParts.push(`Deposit $${Math.round(entry.initialDeposit).toLocaleString()}`);
        }
        if (typeof entry.amountAfterFee === 'number') {
            detailParts.push(`Cashout $${Math.round(entry.amountAfterFee).toLocaleString()}`);
        }
        if (typeof entry.fee === 'number') {
            detailParts.push(`Fee $${Math.round(entry.fee).toLocaleString()}`);
        }

        const detailLine = detailParts.length ? `${detailParts.join(' • ')} • ${dateLabel}` : dateLabel;
        const roundLabel = entry.roundNumber ? `Round ${entry.roundNumber}` : 'Trading Round';

        return `
            <div class="earnings-entry">
                <div class="earnings-entry-details">
                    <div class="earnings-entry-label">${roundLabel}</div>
                    <div class="earnings-entry-date">${detailLine}</div>
                </div>
                <div class="earnings-entry-amount ${amountClass}">${amountLabel}</div>
            </div>
        `;
    }).join('');
}

function updateSpendingHistoryPanel() {
    const listEl = document.getElementById('spendingHistoryList');
    if (!listEl) return;

    const history = (state.spendingHistory || []).slice().sort((a, b) => a.timestamp - b.timestamp);
    if (history.length === 0) {
        listEl.innerHTML = '<div class="spending-entry-empty">No spendings recorded yet.</div>';
        return;
    }

    listEl.innerHTML = history.map(entry => {
        const dateLabel = new Date(entry.timestamp).toLocaleString();
        return `
            <div class="spending-entry">
                <div class="spending-entry-details">
                    <div class="spending-entry-label">${entry.label}</div>
                    <div class="spending-entry-date">${dateLabel}</div>
                </div>
                <div class="spending-entry-amount">-$${entry.amount.toLocaleString()}</div>
            </div>
        `;
    }).join('');
}

function toggleEarningsPanel() {
    const panel = document.getElementById('bankEarningsPanel');
    const button = document.getElementById('earningsToggleButton');
    if (!panel) return;

    const isVisible = panel.classList.toggle('visible');
    if (button) {
        button.classList.toggle('active', isVisible);
        button.setAttribute('aria-expanded', isVisible);
    }
}

function toggleSpendingPanel() {
    const panel = document.getElementById('bankSpendingPanel');
    const button = document.getElementById('spendingToggleButton');
    if (!panel) return;

    const isVisible = panel.classList.toggle('visible');
    if (button) {
        button.classList.toggle('active', isVisible);
        button.setAttribute('aria-expanded', isVisible);
    }
}

// ===========================================
// LOANS
// ===========================================

const MS_PER_WEEK = 7 * 24 * 60 * 60 * 1000;

// Generate deterministic interest rate based on current date
// Same date = same rate, ensuring rate is locked when loan is taken
function getCurrentLoanInterestRate() {
    if (!LOAN_CONFIG) return LOAN_CONFIG.rateMin;
    
    // Get current date as YYYY-MM-DD string for deterministic seed
    const today = new Date();
    const dateString = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    
    // Create a simple hash from date string for deterministic randomness
    let hash = 0;
    for (let i = 0; i < dateString.length; i++) {
        const char = dateString.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    
    // Use mulberry32-like PRNG for better distribution
    const seed = Math.abs(hash);
    let t = seed + 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    const random = ((t ^ t >>> 14) >>> 0) / 4294967296;
    
    // Generate rate within min/max range
    const rate = LOAN_CONFIG.rateMin + (random * (LOAN_CONFIG.rateMax - LOAN_CONFIG.rateMin));
    
    // Round to 2 decimal places (e.g., 0.0875 = 8.75%)
    return Number(rate.toFixed(4));
}

function getLoanElapsedWeeks(loan) {
    const elapsedMs = Date.now() - loan.startTimestamp;
    return Math.max(0, Math.min(loan.termWeeks, elapsedMs / MS_PER_WEEK));
}

function calculateLoanInterest(principal, weeklyRate, weeks) {
    if (weeks <= 0) return 0;
    return Math.round(principal * (Math.pow(1 + weeklyRate, weeks) - 1));
}

function getLoanPayoff(loan, useFullTerm = false) {
    const weeks = useFullTerm ? loan.termWeeks : getLoanElapsedWeeks(loan);
    const interest = calculateLoanInterest(loan.principal, loan.annualRate, weeks);
    return {
        interest,
        total: Math.round(loan.principal + interest),
        weeks
    };
}

function formatLoanRate(rate) {
    return `${(rate * 100).toFixed(2).replace(/\.00$/, '')}%`;
}

function renderLoanOptions() {
    const container = document.getElementById('loanOptionsList');
    if (!container || typeof LOAN_CONFIG === 'undefined') return;
    
    const hasLoan = !!state.activeLoan;
    const lifetimeEarnings = state.totalEarnings || 0;
    
    // Player can take loan if they have lifetime earnings and no active loan
    const isDisabled = hasLoan || lifetimeEarnings <= 0;
    
    let lockMessage = '';
    if (lifetimeEarnings <= 0) {
        lockMessage = `<div class="loan-lock-message">🔒 Unavailable - You need lifetime earnings to get a loan</div>`;
    } else if (hasLoan) {
        lockMessage = `<div class="loan-lock-message">🔒 Unavailable - You already have an active loan</div>`;
    }
    
    const loanAmount = lifetimeEarnings;
    // Get current date-based interest rate (deterministic - same date = same rate)
    const currentRate = getCurrentLoanInterestRate();
    const currentRatePercent = (currentRate * 100).toFixed(2);
    
    container.className = `loan-options ${isDisabled ? 'disabled' : ''}`;
    container.innerHTML = `
        ${lockMessage}
        <div class="loan-bubbles-container">
            <div class="loan-top-bubble">
                <div class="loan-bubble-row">
                    <div class="loan-bubble-item">
                        <div class="loan-bubble-label">Term</div>
                        <div class="loan-bubble-value">${LOAN_CONFIG.termWeeks} week</div>
                    </div>
                    <div class="loan-bubble-divider"></div>
                    <div class="loan-bubble-item">
                        <div class="loan-bubble-label">Interest Rate</div>
                        <div class="loan-bubble-value">${currentRatePercent}%</div>
                    </div>
                </div>
                <div class="loan-bubble-hint">Today's rate (locked once loan)</div>
            </div>
            <div class="loan-bottom-bubble">
                <div class="loan-bubble-label">Loan Amount</div>
                <div class="loan-bubble-value">$${loanAmount.toLocaleString()}</div>
                <div class="loan-bubble-hint">Based on lifetime earnings</div>
            </div>
        </div>
        <button class="loan-option-btn" onclick="takeLoan()" ${isDisabled ? 'disabled' : ''}>
            ${hasLoan ? 'Already have loan' : lifetimeEarnings <= 0 ? 'No earnings yet' : 'Take loan'}
        </button>
    `;
}

function updateLoanDisplay() {
    const activeCard = document.getElementById('loanActiveCard');
    if (!activeCard) return;
    
    const loan = state.activeLoan;
    if (!loan) {
        activeCard.classList.add('hidden');
        activeCard.classList.remove('empty');
        activeCard.textContent = '';
        return;
    }
    
    activeCard.classList.remove('empty', 'hidden');
    
    const payoffToday = getLoanPayoff(loan);
    const payoffFull = getLoanPayoff(loan, true);
    const dueDate = new Date(loan.dueTimestamp).toLocaleDateString();
    const remainingDays = Math.max(0, Math.ceil((loan.dueTimestamp - Date.now()) / (1000 * 60 * 60 * 24)));
    const isOverdue = Date.now() >= loan.dueTimestamp;
    
    activeCard.innerHTML = `
        <div><strong>${loan.name}</strong> is active.</div>
        <div class="loan-active-grid">
            <div class="loan-active-item">Principal<strong>$${loan.principal.toLocaleString()}</strong></div>
            <div class="loan-active-item">Rate<strong>${formatLoanRate(loan.annualRate)} p.w.</strong></div>
            <div class="loan-active-item">Term<strong>${loan.termWeeks} weeks</strong></div>
            <div class="loan-active-item">Due date<strong>${dueDate}</strong></div>
            <div class="loan-active-item">Payoff today<strong>$${payoffToday.total.toLocaleString()}</strong></div>
            <div class="loan-active-item">${isOverdue ? 'Overdue by' : 'Days remaining'}<strong>${remainingDays} days</strong></div>
        </div>
        <div class="loan-option-detail">Full term payoff: $${payoffFull.total.toLocaleString()}</div>
        <button class="loan-repay-btn" onclick="repayLoan()">Repay loan now</button>
    `;
}

async function takeLoan() {
    if (state.activeLoan) {
        showNotification('You already have an active loan.', 'error');
        return;
    }
    
    if (!LOAN_CONFIG) {
        showNotification('Loan system not configured.', 'error');
        return;
    }
    
    // Check if player has lifetime earnings
    const lifetimeEarnings = state.totalEarnings || 0;
    if (lifetimeEarnings <= 0) {
        showNotification('You need lifetime earnings to get a loan.', 'error');
        return;
    }
    
    // No restriction on taking loans when broke - players can always take loans if they have lifetime earnings
    
    // Loan amount = lifetime earnings
    const amount = lifetimeEarnings;
    
    // Get the current date-based interest rate (same as shown in UI - locked)
    const rate = getCurrentLoanInterestRate();
    
    // Fixed 1 week term
    const termWeeks = LOAN_CONFIG.termWeeks;
    const startTimestamp = Date.now();
    const dueTimestamp = startTimestamp + termWeeks * MS_PER_WEEK;
    
    const fullPayoff = getLoanPayoff({
        principal: amount,
        annualRate: rate,
        termWeeks,
        startTimestamp
    }, true);
    
    state.activeLoan = {
        id: LOAN_CONFIG.id,
        name: LOAN_CONFIG.name,
        principal: amount,
        annualRate: rate,
        termWeeks,
        startTimestamp,
        dueTimestamp,
        fullPayoffAmount: fullPayoff.total
    };
    
    state.bankBalance += amount;
    await saveGameState();
    updateBankerDisplay();
    renderLoanOptions();
    
    showNotification(`Loan approved for $${amount.toLocaleString()} at ${(rate * 100).toFixed(2)}% per week!`, 'success');
}

async function repayLoan() {
    const loan = state.activeLoan;
    if (!loan) return;
    
    const useFullTerm = Date.now() >= loan.dueTimestamp;
    const payoff = getLoanPayoff(loan, useFullTerm);
    
    if (state.bankBalance < payoff.total) {
        showNotification('Insufficient bank balance to repay loan.', 'error');
        return;
    }
    
    state.bankBalance -= payoff.total;
    const interestPaid = Math.max(0, payoff.total - loan.principal);
    addSpendingEntry({
        amount: interestPaid,
        type: 'loan-interest',
        label: `Loan interest (${loan.name})`
    });
    state.activeLoan = null;
    await saveGameState();
    updateBankerDisplay();
    renderLoanOptions();
    
    showNotification(`Loan repaid for $${payoff.total.toLocaleString()}.`, 'success');
    
    // Check for game over condition after repaying loan
    checkGameOver();
}

async function processLoanDue() {
    const loan = state.activeLoan;
    if (!loan) return;
    
    if (Date.now() >= loan.dueTimestamp) {
        const payoff = getLoanPayoff(loan, true);
        state.bankBalance -= payoff.total;
        const interestPaid = Math.max(0, payoff.total - loan.principal);
        addSpendingEntry({
            amount: interestPaid,
            type: 'loan-interest',
            label: `Loan interest (${loan.name})`
        });
        state.activeLoan = null;
        await saveGameState();
        updateBankerDisplay();
        renderLoanOptions();
        showNotification(`Loan auto-repaid for $${payoff.total.toLocaleString()}.`, 'info');
        
        // Check for game over condition
        checkGameOver();
    }
}

function initLoanSystem() {
    processLoanDue();
    updateLoanDisplay();
    renderLoanOptions();
}

// Set deposit amount from preset
function setDepositAmount(amount) {
    const input = document.getElementById('depositAmountInput');
    if (input) {
        input.value = amount;
    }
}

// Deposit all bank balance
function depositAll() {
    const input = document.getElementById('depositAmountInput');
    if (input) {
        input.value = state.bankBalance;
    }
}

// Execute deposit
function executeDeposit() {
    const input = document.getElementById('depositAmountInput');
    if (!input) return;
    
    const amount = parseInt(input.value) || 0;
    const result = depositToTrading(amount);
    
    if (result.success) {
        AudioManager.playClick();
        showNotification(result.message, 'success');
        updateBankerDisplay();
        updateTraderLockState();
        input.value = '';
    } else {
        showNotification(result.message, 'error');
    }
}

// Update trader app lock state
function updateTraderLockState() {
    const traderApp = document.getElementById('traderAppIcon');
    if (traderApp) {
        if (hasTradingFunds()) {
            traderApp.classList.remove('locked');
        } else {
            traderApp.classList.add('locked');
        }
    }
}

// Close any phone overlays
function closePhoneOverlays() {
    closeBankerApp();
    closeTraderLocked();
    closeShopApp();
    closeExpensesApp();
    closeLeaderboardApp();
    closeSettingsApp();
}

// ===========================================
// SHOP APP
// ===========================================

let currentShopCategory = 'estate';

// Open shop app (luxury shop)
function openShopApp() {
    const overlay = document.getElementById('shopAppOverlay');
    if (overlay) {
        overlay.classList.add('visible');
        updateLuxuryShopDisplay();
        renderLuxuryShopItems();
    }
}

// Close shop app
function closeShopApp() {
    const overlay = document.getElementById('shopAppOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
}

// Filter shop by category
function filterShopCategory(category) {
    currentShopCategory = category;
    
    // Update tab active state
    document.querySelectorAll('.shop-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.category === category);
    });
    
    renderLuxuryShopItems();
}

// Update luxury shop display
function updateLuxuryShopDisplay() {
    const balanceEl = document.getElementById('shopBalanceAmount');
    if (balanceEl) {
        balanceEl.textContent = Math.floor(state.bankBalance).toLocaleString();
    }
    
    renderOwnedLuxuryItems();
}

// Render owned luxury items
function renderOwnedLuxuryItems() {
    const container = document.getElementById('shopOwnedList');
    const section = document.getElementById('shopOwnedSection');
    
    if (!container || !section) return;
    
    if (state.ownedItems.length === 0) {
        section.style.display = 'none';
        return;
    }
    
    section.style.display = 'block';
    
    container.innerHTML = state.ownedItems.map(item => {
        // Calculate potential sell return range for display
        const minReturn = Math.floor(item.price * ITEM_SELL_RETURN_PERCENT.min);
        const maxReturn = Math.floor(item.price * ITEM_SELL_RETURN_PERCENT.max);
        
        return `
        <div class="shop-owned-item">
            <div class="shop-owned-item-icon">${item.icon}</div>
            <div class="shop-owned-item-info">
                <div class="shop-owned-item-name">${item.name}</div>
                <div class="shop-owned-item-desc">Sell: $${minReturn.toLocaleString()}-${maxReturn.toLocaleString()}</div>
            </div>
            <button class="shop-sell-btn" onclick="sellShopItem('${item.id}')">Sell</button>
        </div>
    `;
    }).join('');
}

// Format price with K/M abbreviations
function formatShopPrice(price) {
    if (price >= 1000000) {
        return '$' + (price / 1000000).toFixed(price % 1000000 === 0 ? 0 : 1) + 'M';
    } else if (price >= 1000) {
        return '$' + (price / 1000).toFixed(price % 1000 === 0 ? 0 : 0) + 'K';
    }
    return '$' + price.toLocaleString();
}

// Render luxury shop items
function renderLuxuryShopItems() {
    const container = document.getElementById('shopItemsList');
    if (!container) return;
    
    const filteredItems = SHOP_ITEMS.filter(item => item.category === currentShopCategory);
    
    container.innerHTML = filteredItems.map(item => {
        const owned = state.ownedItems.some(ownedItem => ownedItem.id === item.id);
        const canAfford = state.bankBalance >= item.price;
        
        let statusClass = '';
        let buttonText = 'Buy';
        let buttonDisabled = false;
        
        if (owned) {
            statusClass = 'owned';
            buttonText = 'Owned';
            buttonDisabled = true;
        } else if (!canAfford) {
            buttonDisabled = true;
            buttonText = 'Buy';
        }
        
        return `
            <div class="shop-item ${statusClass}">
                <div class="shop-item-icon">${item.icon}</div>
                <div class="shop-item-info">
                    <div class="shop-item-name">${item.name}</div>
                    <div class="shop-item-price">
                        <div class="shop-item-price-value">${formatShopPrice(item.price)}</div>
                    </div>
                    <button class="shop-buy-btn" ${buttonDisabled ? 'disabled' : ''} onclick="buyShopItem('${item.id}')">${buttonText}</button>
                </div>
            </div>
        `;
    }).join('');
}

// Buy shop item
function buyShopItem(itemId) {
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item) return;
    
    // Check if already owned
    if (state.ownedItems.some(ownedItem => ownedItem.id === itemId)) {
        return;
    }
    
    // Check if can afford
    if (state.bankBalance < item.price) {
        showNotification('Insufficient funds!', 'error');
        return;
    }
    
    // Play click sound for purchase
    AudioManager.playClick();
    
    // Deduct price from bank balance
    state.bankBalance -= item.price;
    addSpendingEntry({
        amount: item.price,
        type: 'luxury',
        label: `Luxury purchase: ${item.name}`
    });
    
    // Add to owned items
    state.ownedItems.push({
        id: item.id,
        name: item.name,
        category: item.category,
        icon: item.icon,
        price: item.price,
        description: item.description
    });
    
    // Save game state
    saveGameState();
    
    // Update displays
    updateLuxuryShopDisplay();
    updateBankerDisplay();
    updateExpensesDisplay();
    renderExpensesList();
    renderLuxuryShopItems();
    
    // Show notification
    let message = `Purchased ${item.name} for $${item.price.toLocaleString()}!`;
    if (item.category === 'estate') {
        message += ' Rent expense eliminated!';
    } else if (item.category === 'car') {
        message += ' Transport expense eliminated!';
    }
    
    showNotification(message, 'success');
}

// Sell shop item
function sellShopItem(itemId) {
    const itemIndex = state.ownedItems.findIndex(item => item.id === itemId);
    if (itemIndex === -1) {
        showNotification('Item not found!', 'error');
        return;
    }
    
    const item = state.ownedItems[itemIndex];
    
    // Calculate random return percentage within configured spread
    const returnPercent = ITEM_SELL_RETURN_PERCENT.min + 
        Math.random() * (ITEM_SELL_RETURN_PERCENT.max - ITEM_SELL_RETURN_PERCENT.min);
    const returnAmount = Math.floor(item.price * returnPercent);
    
    // Play click sound for sale
    AudioManager.playClick();
    
    // Add return amount to bank balance
    state.bankBalance += returnAmount;
    
    // Track earnings
    addSpendingEntry({
        amount: -returnAmount, // Negative for earnings
        type: 'luxury',
        label: `Item sold: ${item.name}`
    });
    
    // Remove from owned items
    state.ownedItems.splice(itemIndex, 1);
    
    // Save game state
    saveGameState();
    
    // Update displays
    updateLuxuryShopDisplay();
    updateBankerDisplay();
    updateExpensesDisplay();
    renderExpensesList();
    renderLuxuryShopItems();
    
    // Show notification with return amount
    const returnPercentDisplay = Math.round(returnPercent * 100);
    let message = `Sold ${item.name} for $${returnAmount.toLocaleString()} (${returnPercentDisplay}% of original price)`;
    
    // Warn if selling estate or car (expenses will return)
    if (item.category === 'estate') {
        message += '. Rent expense will return!';
    } else if (item.category === 'car') {
        message += '. Transport expense will return!';
    }
    
    showNotification(message, 'success');
}

// ===========================================
// EXPENSES APP
// ===========================================

let midnightCheckInterval = null;

// Get current date as YYYY-MM-DD string
function getTodayDateString() {
    const now = new Date();
    return now.toISOString().split('T')[0];
}

// Calculate days between two date strings (YYYY-MM-DD)
function getDaysBetween(dateStr1, dateStr2) {
    if (!dateStr1 || !dateStr2) return 0;
    const date1 = new Date(dateStr1);
    const date2 = new Date(dateStr2);
    const diffTime = Math.abs(date2 - date1);
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

// Open expenses app
function openExpensesApp() {
    const overlay = document.getElementById('expensesAppOverlay');
    if (overlay) {
        overlay.classList.add('visible');
        renderExpensesList();
        updateExpensesDisplay();
    }
}

// Close expenses app
function closeExpensesApp() {
    const overlay = document.getElementById('expensesAppOverlay');
    if (overlay) {
        overlay.classList.remove('visible');
    }
}

// Render expenses list
function renderExpensesList() {
    const container = document.getElementById('expensesList');
    if (!container) return;
    
    container.innerHTML = DAILY_EXPENSES.map(expense => {
        // Check if this expense is eliminated by an owned item
        let isEliminated = false;
        if (expense.canEliminate && expense.eliminatedBy) {
            isEliminated = state.ownedItems.some(item => 
                item.category === expense.eliminatedBy
            );
        }
        
        const classNames = [];
        if (!expense.enabled) classNames.push('disabled');
        if (isEliminated) classNames.push('disabled');
        
        // Get current amount (custom or default)
        const currentAmount = state.customExpenseAmounts[expense.id] !== undefined 
            ? state.customExpenseAmounts[expense.id] 
            : expense.amount;
        
        return `
            <div class="expense-item ${classNames.join(' ')}">
                <div class="expense-icon">${expense.icon}</div>
                <div class="expense-info">
                    <div class="expense-name">${expense.name}</div>
                    <div class="expense-desc">${isEliminated ? '✅ Eliminated!' : expense.description}</div>
                </div>
                ${isEliminated ? 
                    '<div class="expense-amount">FREE</div>' : 
                    `<div class="expense-amount-controls">
                        <button class="expense-adjust-btn" onclick="adjustExpense('${expense.id}', -1)">-</button>
                        <input type="number" 
                               class="expense-amount-input" 
                               value="${currentAmount}" 
                               min="${expense.amount}"
                               max="999"
                               onchange="setExpenseAmount('${expense.id}', this.value)"
                               onclick="event.stopPropagation()">
                        <button class="expense-adjust-btn" onclick="adjustExpense('${expense.id}', 1)">+</button>
                    </div>`
                }
            </div>
        `;
    }).join('');
}

// Adjust expense amount
function adjustExpense(expenseId, delta) {
    const expense = DAILY_EXPENSES.find(e => e.id === expenseId);
    if (!expense) return;
    
    const currentAmount = state.customExpenseAmounts[expenseId] !== undefined 
        ? state.customExpenseAmounts[expenseId] 
        : expense.amount;
    
    const newAmount = Math.max(expense.amount, Math.min(999, currentAmount + delta));
    
    if (newAmount !== currentAmount) {
        state.customExpenseAmounts[expenseId] = newAmount;
        saveGameState();
        renderExpensesList();
        updateExpensesDisplay();
    }
}

// Set expense amount directly
function setExpenseAmount(expenseId, value) {
    const expense = DAILY_EXPENSES.find(e => e.id === expenseId);
    if (!expense) return;
    
    const amount = parseInt(value) || expense.amount;
    const clampedAmount = Math.max(expense.amount, Math.min(999, amount));
    
    state.customExpenseAmounts[expenseId] = clampedAmount;
    saveGameState();
    renderExpensesList();
    updateExpensesDisplay();
}

// Update expenses display
function updateExpensesDisplay() {
    const totalEl = document.getElementById('expensesTotalAmount');
    const countdownEl = document.getElementById('expensesCountdown');
    const lastPaidEl = document.getElementById('expensesLastPaid');
    
    if (totalEl) {
        const total = getTotalDailyExpenses(state.ownedItems, state.customExpenseAmounts);
        totalEl.textContent = '-$' + total;
    }
    
    if (countdownEl) {
        // Calculate time until midnight
        const now = new Date();
        const midnight = new Date(now);
        midnight.setHours(24, 0, 0, 0);
        const msUntilMidnight = midnight - now;
        const hoursLeft = Math.floor(msUntilMidnight / (1000 * 60 * 60));
        const minsLeft = Math.floor((msUntilMidnight % (1000 * 60 * 60)) / (1000 * 60));
        countdownEl.textContent = `${hoursLeft}h ${minsLeft}m`;
    }
}

// Initialize expense system on login
function initExpenseSystem() {
    const today = getTodayDateString();
    const lastExpenseDate = state.lastExpenseDate;
    
    // If no previous expense date, set to today (first login)
    if (!lastExpenseDate) {
        state.lastExpenseDate = today;
        saveGameState();
        console.log('First login - expense tracking started');
        return;
    }
    
    // Calculate days since last expense charge
    const daysMissed = getDaysBetween(lastExpenseDate, today);
    
    if (daysMissed > 0) {
        const totalExpenses = getTotalDailyExpenses(state.ownedItems, state.customExpenseAmounts);
        const missedAmount = daysMissed * totalExpenses;
        
        if (missedAmount > 0) {
            state.bankBalance -= missedAmount;
            addSpendingEntry({
                amount: missedAmount,
                type: 'expense',
                label: `Daily expenses (${daysMissed} days)`
            });
            state.lastExpenseDate = today;
            saveGameState();
            updateBankerDisplay();
            
            console.log(`Charged ${daysMissed} days of expenses: -$${missedAmount}`);
            
            // Show notification for missed expenses
            setTimeout(() => {
                showExpenseNotification(missedAmount, daysMissed);
            }, 1000);
            
            // Check for game over condition after missed expenses
            checkGameOver();
        }
    }
    
    // Start midnight check to charge at day change
    startMidnightCheck();
}

// Start checking for midnight (day change)
function startMidnightCheck() {
    if (midnightCheckInterval) {
        clearInterval(midnightCheckInterval);
    }
    
    // Check every minute for day change
    midnightCheckInterval = setInterval(() => {
        checkForDayChange();
    }, 60000); // Check every minute
}

// Check if day has changed and charge expenses
function checkForDayChange() {
    if (!isLoggedIn) return;
    
    const today = getTodayDateString();
    
    if (state.lastExpenseDate !== today) {
        chargeExpenses();
    }

    processLoanDue();
}

// Charge expenses for a new day
function chargeExpenses() {
    if (!isLoggedIn) return;
    
    const totalExpenses = getTotalDailyExpenses(state.ownedItems, state.customExpenseAmounts);
    if (totalExpenses <= 0) return;
    
    const today = getTodayDateString();
    
    // Deduct from bank balance
    state.bankBalance -= totalExpenses;
    addSpendingEntry({
        amount: totalExpenses,
        type: 'expense',
        label: 'Daily expenses'
    });
    
    // Update last expense date
    state.lastExpenseDate = today;
    
    // Save state
    saveGameState();
    
    // Update displays
    updateBankerDisplay();
    updateExpensesDisplay();
    
    // Show notification
    showExpenseNotification(totalExpenses, 1);
    
    // Check if bankrupt
    if (state.bankBalance < 0) {
        console.log('Bank balance is negative! Debt: $' + Math.abs(state.bankBalance));
    }
    
    // Check for game over condition
    checkGameOver();
}

// Show expense deduction notification
function showExpenseNotification(amount, days = 1) {
    // Create notification element if it doesn't exist
    let notif = document.getElementById('expenseNotification');
    if (!notif) {
        notif = document.createElement('div');
        notif.id = 'expenseNotification';
        notif.className = 'expense-notification';
        document.body.appendChild(notif);
    }
    
    if (days > 1) {
        notif.textContent = `${days} days expenses: -$${amount}`;
    } else {
        notif.textContent = `Daily expenses: -$${amount}`;
    }
    notif.classList.add('show');
    
    setTimeout(() => {
        notif.classList.remove('show');
    }, 4000);
}

// ===========================================
// GAME OVER CHECK
// ===========================================

let gameOverModalOpen = false;

// Check if game over condition is met (bank balance < $50 AND trading balance < $50 AND no ability to get a loan)
function checkGameOver() {
    if (!isLoggedIn) return; // Don't check if not logged in
    
    const portfolioValue = getTotalPortfolioValue();
    const bankBalance = state.bankBalance;
    const hasActiveLoan = state.activeLoan !== null;
    const GAME_OVER_THRESHOLD = 50; // Game over if both accounts are below $50
    const lifetimeEarnings = state.totalEarnings || 0;
    
    // Check if both accounts are below threshold
    const isBroke = bankBalance < GAME_OVER_THRESHOLD && portfolioValue < GAME_OVER_THRESHOLD;
    
    if (!isBroke) return; // Not broke, no game over
    
    // Check if player can get a loan
    // Player can't get a loan if:
    // 1. They already have an active loan, OR
    // 2. They have no lifetime earnings (loan amount = lifetime earnings)
    const canGetLoan = !hasActiveLoan && lifetimeEarnings > 0;
    
    // Game over: broke AND can't get a loan
    if (!canGetLoan) {
        showGameOverModal();
    }
}

// Show game over modal
function showGameOverModal() {
    if (gameOverModalOpen) return; // Already showing
    
    gameOverModalOpen = true;
    
    // Close all other overlays
    if (typeof closePhoneOverlays === 'function') {
        closePhoneOverlays();
    }
    
    const modal = document.getElementById('gameOverModal');
    const backdrop = document.getElementById('gameOverBackdrop');
    const messageEl = document.getElementById('gameOverMessage');
    
    // Update message based on why game over occurred
    const lifetimeEarnings = state.totalEarnings || 0;
    const hasActiveLoan = state.activeLoan !== null;
    let reason = '';
    
    if (hasActiveLoan) {
        reason = 'You already have an active loan and cannot get another one.';
    } else if (lifetimeEarnings <= 0) {
        reason = 'You have no lifetime earnings, so no loan is available (loan amount = lifetime earnings).';
    } else {
        reason = 'No loans are available to you.';
    }
    
    if (messageEl) {
        messageEl.textContent = `You have less than $50 in your bank account and less than $50 in your trading account. ${reason} Your trading journey has come to an end.`;
    }
    
    if (modal && backdrop) {
        modal.classList.add('open');
        backdrop.classList.add('open');
    }
}

// Close game over modal
function closeGameOverModal() {
    gameOverModalOpen = false;
    const modal = document.getElementById('gameOverModal');
    const backdrop = document.getElementById('gameOverBackdrop');
    
    if (modal && backdrop) {
        modal.classList.remove('open');
        backdrop.classList.remove('open');
    }
}

// Restart game from game over screen (uses same logic as settings reset)
async function restartGameFromGameOver() {
    // Use the same reset logic as settings menu
    if (typeof executeResetGame === 'function') {
        await executeResetGame();
    }
    
    // Close game over modal
    closeGameOverModal();
}

// Start the game (hide hub, show game)
function startGame() {
    const hubScreen = document.getElementById('hubScreen');
    const appContainer = document.getElementById('appContainer');
    const phoneToggleBtn = document.getElementById('phoneToggleBtn');
    
    if (hubScreen) {
        hubScreen.classList.add('hidden');
    }
    if (appContainer) {
        appContainer.classList.remove('hidden');
    }
    if (phoneToggleBtn) {
        // Show the toggle button after a short delay
        setTimeout(() => {
            phoneToggleBtn.classList.add('visible');
        }, 500);
    }
    
    if (!gameStarted) {
        gameStarted = true;
        // Initialize the actual game
        initGameSystems();
    }
}

// Toggle phone visibility during gameplay
function togglePhone() {
    const hubScreen = document.getElementById('hubScreen');
    const appContainer = document.getElementById('appContainer');
    const phoneToggleBtn = document.getElementById('phoneToggleBtn');
    const phoneHint = document.getElementById('phoneHint');
    
    if (!hubScreen) return;
    
    const isHubVisible = !hubScreen.classList.contains('hidden');
    
    if (isHubVisible && gameStarted) {
        // Hide phone, return to game
        hubScreen.classList.add('hidden');
        if (appContainer) appContainer.classList.remove('hidden');
        if (phoneToggleBtn) phoneToggleBtn.classList.add('visible');
    } else if (gameStarted) {
        // Show phone
        hubScreen.classList.remove('hidden');
        if (appContainer) appContainer.classList.add('hidden');
        if (phoneToggleBtn) phoneToggleBtn.classList.remove('visible');
        
        // Show the hint now that game has started
        if (phoneHint) phoneHint.classList.add('visible');
        
        // Reset any launching animations
        const launchingApps = document.querySelectorAll('.phone-app.launching');
        launchingApps.forEach(app => app.classList.remove('launching'));
        
        // Close any open overlays and update state
        closePhoneOverlays();
        updateTraderLockState();
        updateBankerDisplay();
    }
}

// ===========================================
// PRESTIGE SYSTEM
// ===========================================

// Show prestige confirmation
function confirmPrestige() {
    const portfolioValue = getTotalPortfolioValue();
    
    if (portfolioValue <= 0) {
        showNotification('No funds to cash out', 'error');
        return;
    }
    
    // Calculate fee and amount after fee
    const fee = getCashOutFee(portfolioValue);
    const amountAfterFee = portfolioValue - fee;
    const netProfit = amountAfterFee - state.initialDeposit;
    
    // Update modal display
    const portfolioEl = document.getElementById('prestigePortfolioValue');
    const feeEl = document.getElementById('prestigeFee');
    const netProfitEl = document.getElementById('prestigeNetProfit');
    const receiveEl = document.getElementById('prestigeReceive');
    const profitRow = document.getElementById('prestigeProfitRow');
    
    if (portfolioEl) portfolioEl.textContent = '$' + Math.floor(portfolioValue).toLocaleString();
    if (feeEl) feeEl.textContent = '-$' + Math.floor(fee).toLocaleString();
    if (netProfitEl) {
        const profitPrefix = netProfit >= 0 ? '+$' : '-$';
        netProfitEl.textContent = profitPrefix + Math.abs(Math.floor(netProfit)).toLocaleString();
    }
    if (receiveEl) receiveEl.textContent = '$' + Math.floor(amountAfterFee).toLocaleString();
    
    // Update profit row styling
    if (profitRow) {
        profitRow.classList.remove('positive', 'negative');
        profitRow.classList.add(netProfit >= 0 ? 'positive' : 'negative');
    }
    
    // Show modal
    document.getElementById('prestigeBackdrop')?.classList.add('open');
    document.getElementById('prestigeModal')?.classList.add('open');
}

// Cancel prestige
function cancelPrestige() {
    document.getElementById('prestigeBackdrop')?.classList.remove('open');
    document.getElementById('prestigeModal')?.classList.remove('open');
}

// Execute prestige
function executePrestige() {
    const result = prestigeToBank();
    
    if (result.success) {
        AudioManager.playClick();
        cancelPrestige();

        addEarningsEntry({
            roundNumber: result.roundNumber,
            amountAfterFee: result.amount,
            fee: result.fee,
            netProfit: result.netProfit,
            initialDeposit: result.initialDeposit
        });
        saveGameState();
        
        // Show success notification
        showNotification(result.message, 'success');
        
        // Update UI
        updateBalanceDisplay();
        renderDeals();
        renderPositions();
        renderStockHolding();
        renderCookieInventory();
        updateComboCounter();
        
        // Return to phone
        togglePhone();
    } else {
        showNotification(result.message, 'error');
    }
}

// Initialize hub screen
async function initHub() {
    // Start phone time update
    updatePhoneTime();
    setInterval(updatePhoneTime, 1000);
    
    // Hide app container initially
    const appContainer = document.getElementById('appContainer');
    if (appContainer) {
        appContainer.classList.add('hidden');
    }
    
    // Initialize login card
    initLoginCard();
    
    // Check for saved credentials
    const savedCredentials = loadCredentials();
    if (savedCredentials) {
        // Auto-login with saved credentials
        playerName = savedCredentials.playerName;
        if (savedCredentials.playerId) {
            playerId = savedCredentials.playerId;
            isLoggedIn = true;
        }
    }
    
    // Singleplayer mode: Auto-login if not already logged in
    if (!isLoggedIn) {
        // Use saved name or default
        playerName = savedCredentials?.playerName || 'Player';
        const nameKey = normalizePlayerName(playerName);
        playerId = `sp_${nameKey}_${Date.now()}`;
        isLoggedIn = true;
        saveCredentials();
    }

    if (isLoggedIn) {
        // Load game state from localStorage (singleplayer mode)
        await loadGameState();
        
        // Hide login card
        const loginContainer = document.getElementById('loginCardContainer');
        if (loginContainer) {
            loginContainer.classList.add('hidden');
        }
        
        // Check for game over condition after loading state
        checkGameOver();
        
        // Start expense system
        initExpenseSystem();
        initLoanSystem();
        updatePlayerDisplay();
        
        console.log(`Playing as: ${playerName} (Singleplayer Mode)`);
    } else {
        // Show login card on first load (shouldn't happen in singleplayer)
        showLoginCard();
    }
    
    // Update trader lock state based on current funds
    updateTraderLockState();
    updateBankerDisplay();
    
    // Add keyboard shortcut to toggle phone (Escape key)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (gameStarted) {
                togglePhone();
            } else {
                // Close any open overlays in phone
                closePhoneOverlays();
            }
        }
    });
}

// Show/hide chart loading overlay
function showChartLoading(show) {
    const overlay = document.getElementById('chartLoadingOverlay');
    if (overlay) {
        overlay.style.display = show ? 'flex' : 'none';
    }
}

// Data source change handler
// Charts are already running in background - this just switches which one is displayed
function changeDataSource(source) {
    const status = document.getElementById('sourceStatus');
    const assetName = document.getElementById('assetName');
    const assetTag = document.getElementById('assetTag');
    const config = stockConfig[source];
    
    state.dataMode = source;
    assetName.textContent = config.name;
    assetTag.textContent = config.tag;
    
    // Clear time frame cache for this symbol (will regenerate on demand)
    clearTimeFrameCache(source);
    
    // Reset to LIVE time frame when switching stocks
    state.currentTimeFrame = 'LIVE';
    
    // Update time frame button UI
    document.querySelectorAll('.time-frame-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.frame === 'LIVE') {
            btn.classList.add('active');
        }
    });
    
    // Charts are pre-initialized and running in background
    // Just sync the active state to global state
    if (state.chartPrices[source]) {
        const prices = state.chartPrices[source];
        state.currentPrice = prices.currentPrice;
        state.targetPrice = prices.targetPrice;
        // Set displayPrice to currentPrice to avoid interpolation jump on switch
        // (displayPrice was stale from when we last viewed this chart)
        state.displayPrice = prices.currentPrice;
        // Also update stored displayPrice
        prices.displayPrice = prices.currentPrice;
    }
    
    if (state.chartSimState[source]) {
        state.sim = state.chartSimState[source];
    }
    
    // Show LIVE status
    status.textContent = 'LIVE';
    status.classList.add('live');
    
    showChartLoading(false);
    
    // Re-render deals and positions to show only current stock
    renderDeals();
    renderPositions();
    renderStockHolding();
}

// Smooth animation loop using requestAnimationFrame
let lastPnlUpdate = 0;
let lastTimerUpdate = 0;

function smoothAnimationLoop() {
    const now = Date.now();
    
    // Smooth price interpolation (vertical movement only, stays at right edge)
    state.displayPrice = state.displayPrice + (state.targetPrice - state.displayPrice) * 0.12;
    
    // Smooth balance interpolation
    const balanceDiff = state.balance - state.displayBalance;
    if (Math.abs(balanceDiff) > 0.01) {
        state.displayBalance += balanceDiff * 0.1;
    }
    
    // Always update portfolio display (includes stock holdings that change with price)
    updateBalanceDisplay();
    
    // Update price display smoothly
    const priceEl = document.getElementById('currentPrice');
    priceEl.textContent = '$' + state.displayPrice.toFixed(2);
    
    // Update timer bars smoothly (every frame for continuous countdown)
    // Also updates bet lock button states
    updateTimerDisplays(now);
    
    // Update PnL displays every 100ms for smooth transitions
    if (now - lastPnlUpdate > 100) {
        updatePnLDisplays();
        lastPnlUpdate = now;
    }
    
    // Update margin position UI smoothly
    if (typeof renderMarginPosition === 'function') {
        renderMarginPosition();
    }
    
    // Update portfolio overlay in real-time if open
    if (typeof updatePortfolioOverlay === 'function') {
        updatePortfolioOverlay();
    }
    
    // Redraw chart with interpolated values
    drawChartSmooth();
    
    state.animationFrameId = requestAnimationFrame(smoothAnimationLoop);
}

// Reset simulation state for fresh start
function resetSimulationState() {
    state.sim = createFreshSimState();
}

// Create a fresh simulation state object
function createFreshSimState() {
    return {
        volatility: 1,
        volatilityTarget: 1,
        trend: 0,
        trendDuration: 0,
        supports: [],
        resistances: [],
        isConsolidating: false,
        consolidationTicks: 0,
        consolidationCenter: 0,
        consolidationRange: 0,
        breakoutDirection: 0,
        breakoutStrength: 0,
        candle: {
            open: 0,
            high: 0,
            low: 0,
            close: 0,
            ticksInCandle: 0
        },
        candleHistory: [],
        recentHigh: 0,
        recentLow: Infinity
    };
}

// Generate simulated historical prices for a symbol using deterministic seeded RNG
// Returns { history: [{value, timestamp}], simState: {...}, lastPrice: number }
// This ensures the same prices are generated regardless of when/where the page is loaded
// by always simulating from tick 0
function generateSimulatedHistory(symbol, pointCount = CHART_VISIBLE_POINTS) {
    const config = stockConfig[symbol];
    const basePrice = config ? config.basePrice : 100;
    const currentTick = getCurrentTickNumber();
    const history = [];
    
    // Start from the oldest tick we need to display
    const displayStartTick = currentTick - pointCount + 1;
    
    // CRITICAL: Always simulate from epoch start to ensure deterministic results
    // This ensures the same accumulated state regardless of when page is loaded
    // Epochs reset every SIM_EPOCH_SIZE ticks (~5.5 hours) to limit computation
    const currentEpoch = Math.floor(currentTick / SIM_EPOCH_SIZE);
    const epochStartTick = currentEpoch * SIM_EPOCH_SIZE;
    
    // Create simulation state
    const tempSim = createFreshSimState();
    let currentPrice = basePrice;
    
    // Initialize candle
    tempSim.candle.open = currentPrice;
    tempSim.candle.high = currentPrice;
    tempSim.candle.low = currentPrice;
    tempSim.candle.close = currentPrice;
    tempSim.recentHigh = currentPrice;
    tempSim.recentLow = currentPrice;
    
    // Simulate from epoch start to current tick
    // This ensures deterministic state by always starting from the same point
    for (let tick = epochStartTick; tick <= currentTick; tick++) {
        // Create seeded RNG for this specific tick
        const rng = createTickRNG(symbol, tick);
        const cfg = simConfigCache;
        
        // Volatility clustering (deterministic)
        if (rng() < cfg.volatilityChangeChance) {
            if (rng() < cfg.volatilityHighEventChance) {
                tempSim.volatilityTarget = cfg.volatilityHighMin + rng() * (cfg.volatilityHighMax - cfg.volatilityHighMin);
            } else {
                tempSim.volatilityTarget = cfg.volatilityNormalMin + rng() * (cfg.volatilityNormalMax - cfg.volatilityNormalMin);
            }
        }
        tempSim.volatility = tempSim.volatility * 0.9 + tempSim.volatilityTarget * 0.1;
        
        // Trend (deterministic)
        if (tempSim.trendDuration <= 0) {
            tempSim.trend = (rng() - 0.5) * 2;
            tempSim.trendDuration = Math.floor(rng() * 15) + 5;
        }
        tempSim.trendDuration--;
        
        // Get prophecy effects for this symbol at this tick's time
        const tickTime = getTimeForTickNumber(tick);
        const prophecyEffects = getProphecyEffectsForSymbol(symbol, tickTime);
        
        // Calculate price change
        const baseVolatility = currentPrice * cfg.baseVolatility;
        // Apply prophecy volatility multiplier
        const volatility = baseVolatility * tempSim.volatility * prophecyEffects.volatilityMultiplier;
        
        // Seeded Gaussian noise
        const gaussian = seededGaussian(rng);
        const noise = gaussian * volatility * cfg.noiseWeight;
        
        // Trend effect (natural trend, no prophecy bias)
        const trendEffect = tempSim.trend * volatility * cfg.trendWeight;
        
        // Mean reversion
        const deviation = (currentPrice - basePrice) / basePrice;
        const meanReversion = -deviation * currentPrice * cfg.meanReversionWeight;
        
        // Calculate natural price change
        let priceChange = noise + trendEffect + meanReversion;
        
        // Apply trend prophecy reversal logic
        // If price moves against prophecy direction, reverse it with probability
        // Check for conflicting trends first - if both up and down are active, cancel each other out
        const hasTrendUp = prophecyEffects.trendProphecies.some(p => p.type === 'trendUp');
        const hasTrendDown = prophecyEffects.trendProphecies.some(p => p.type === 'trendDown');
        
        if (hasTrendUp && hasTrendDown) {
            // Conflicting trends - cancel each other out (no reversals applied)
            // Price moves naturally without trend interference
        } else {
            // Only one direction active, or multiple same-direction - apply reversals with diminishing returns
            // No threshold - apply to ANY counter-trend movement, no matter how small
            
            // Group same-direction trends and calculate combined probability with diminishing returns
            const trendUpProphecies = prophecyEffects.trendProphecies.filter(p => p.type === 'trendUp');
            const trendDownProphecies = prophecyEffects.trendProphecies.filter(p => p.type === 'trendDown');
            
            if (trendUpProphecies.length > 0 && priceChange < 0) {
                // Any downward movement - reverse with probability
                // Calculate combined probability with diminishing returns
                // Formula: maxProbability + (1 - maxProbability) * min(0.12 * (N-1), 0.25)
                // This makes stacking less effective to encourage upgrading to higher tiers
                const maxProbability = Math.max(...trendUpProphecies.map(p => p.reversalProbability));
                const count = trendUpProphecies.length;
                const bonusMultiplier = Math.min(0.12 * (count - 1), 0.25); // Max 25% bonus
                const effectiveProbability = maxProbability + (1 - maxProbability) * bonusMultiplier;
                
                if (rng() < effectiveProbability) {
                    // Reverse the movement (make it positive)
                    priceChange = Math.abs(priceChange);
                }
            } else if (trendDownProphecies.length > 0 && priceChange > 0) {
                // Any upward movement - reverse with probability
                // Calculate combined probability with diminishing returns
                const maxProbability = Math.max(...trendDownProphecies.map(p => p.reversalProbability));
                const count = trendDownProphecies.length;
                const bonusMultiplier = Math.min(0.12 * (count - 1), 0.25); // Max 25% bonus
                const effectiveProbability = maxProbability + (1 - maxProbability) * bonusMultiplier;
                
                if (rng() < effectiveProbability) {
                    // Reverse the movement (make it negative)
                    priceChange = -Math.abs(priceChange);
                }
            }
        }
        
        // Apply changes
        currentPrice = currentPrice + priceChange;
        
        // No artificial boundaries - prices can move freely
        // Mean reversion naturally keeps prices centered around basePrice
        
        // Only store points for the visible chart range
        if (tick >= displayStartTick) {
            const timestamp = getTimeForTickNumber(tick);
            history.push({
                value: currentPrice,
                timestamp: timestamp
            });
        }
    }
    
    // Return history AND the final simulation state
    return {
        history: history,
        simState: tempSim,
        lastPrice: currentPrice
    };
}

// ===========================================
// TIME FRAME CHART GENERATION
// ===========================================
// Generate history for different time frames (1H, 1D, 1W, 1M, 1Y)
// Uses coarse simulation for performance - simulates at point granularity not tick granularity
// Smoothly transitions to current live price at the end

function generateTimeFrameHistory(symbol, timeFrame, targetPrice = null) {
    const tf = TIME_FRAMES[timeFrame];
    const config = stockConfig[symbol];
    const basePrice = config ? config.basePrice : 100;
    const rawHistory = [];
    
    // Get current live price to transition to
    const livePrice = targetPrice || (state.chartPrices[symbol] ? state.chartPrices[symbol].currentPrice : basePrice);
    
    // Get the anchor tick (current time aligned to time frame boundary)
    const currentTick = getCurrentTickNumber();
    const anchorTick = Math.floor(currentTick / tf.ticksPerPoint) * tf.ticksPerPoint;
    
    // Calculate start tick for this time frame
    const startTick = anchorTick - (tf.displayPoints * tf.ticksPerPoint);
    
    // Create simulation state for this time frame
    const tempSim = createFreshSimState();
    let price = basePrice;
    
    // Use scaled volatility for this time frame
    const volatilityScale = tf.volatilityScale || 1.0;
    const cfg = simConfigCache;
    
    // Simulate each point in the time frame
    for (let i = 0; i < tf.displayPoints; i++) {
        const pointTick = startTick + (i * tf.ticksPerPoint);
        
        // Create a seeded RNG for this specific time frame point
        // Use a different seed space to avoid conflicts with live simulation
        const rng = createCoarseTickRNG(symbol, timeFrame, i);
        
        // Volatility clustering
        if (rng() < cfg.volatilityChangeChance) {
            if (rng() < cfg.volatilityHighEventChance) {
                tempSim.volatilityTarget = cfg.volatilityHighMin + rng() * (cfg.volatilityHighMax - cfg.volatilityHighMin);
            } else {
                tempSim.volatilityTarget = cfg.volatilityNormalMin + rng() * (cfg.volatilityNormalMax - cfg.volatilityNormalMin);
            }
        }
        tempSim.volatility = tempSim.volatility * 0.9 + tempSim.volatilityTarget * 0.1;
        
        // Trend
        if (tempSim.trendDuration <= 0) {
            tempSim.trend = (rng() - 0.5) * 2;
            tempSim.trendDuration = Math.floor(rng() * 15) + 5;
        }
        tempSim.trendDuration--;
        
        // Calculate price change with scaled volatility for time frame
        const effectiveVolatility = cfg.baseVolatility * volatilityScale;
        const baseVol = price * effectiveVolatility;
        const volatility = baseVol * tempSim.volatility;
        
        // Seeded Gaussian noise
        const gaussian = seededGaussian(rng);
        const noise = gaussian * volatility * cfg.noiseWeight;
        
        // Trend effect
        const trendEffect = tempSim.trend * volatility * cfg.trendWeight;
        
        // Mean reversion (stronger for longer time frames to keep prices realistic)
        const meanReversionScale = Math.min(1 + (volatilityScale * 0.3), 3);
        const deviation = (price - basePrice) / basePrice;
        const meanReversion = -deviation * price * cfg.meanReversionWeight * meanReversionScale;
        
        // Apply changes
        price = price + noise + trendEffect + meanReversion;
        
        // No artificial boundaries - prices can move freely
        // Mean reversion naturally keeps prices centered around basePrice
        
        // Add to raw history
        const timestamp = getTimeForTickNumber(pointTick);
        rawHistory.push({
            value: price,
            timestamp: timestamp
        });
    }
    
    // Natural transition to current live price
    // Instead of smooth blending, apply a drift correction with realistic noise
    const transitionPoints = Math.floor(tf.displayPoints * 0.25); // Last 25%
    const simulatedEndPrice = rawHistory[rawHistory.length - 1].value;
    const priceGap = livePrice - simulatedEndPrice;
    
    // If the gap is small, don't adjust
    if (Math.abs(priceGap / livePrice) < 0.005) {
        return rawHistory;
    }
    
    // Create seeded RNG for transition noise (deterministic)
    const transitionRng = createCoarseTickRNG(symbol, timeFrame + '_transition', 0);
    
    // Apply drift correction with noise across the transition zone
    const history = rawHistory.map((point, i) => {
        const distanceFromEnd = rawHistory.length - 1 - i;
        
        if (distanceFromEnd < transitionPoints) {
            // Progress through transition (0 at start, 1 at end)
            const progress = 1 - (distanceFromEnd / transitionPoints);
            
            // Cumulative drift - gradual shift toward target
            // Use quadratic for slightly accelerating drift (natural momentum)
            const driftFactor = progress * progress;
            const baseDrift = priceGap * driftFactor;
            
            // Add realistic noise that diminishes toward the end
            // This keeps volatility but ensures we hit the target
            const noiseScale = (1 - progress) * 0.4; // Noise decreases as we approach end
            const volatility = point.value * cfg.baseVolatility * volatilityScale;
            
            // Use deterministic noise based on point index
            const noiseRng = createCoarseTickRNG(symbol, timeFrame + '_noise', i);
            const noise1 = noiseRng();
            const noise2 = noiseRng();
            // Box-Muller for Gaussian
            const gaussian = Math.sqrt(-2 * Math.log(noise1 + 0.0001)) * Math.cos(2 * Math.PI * noise2);
            const priceNoise = gaussian * volatility * noiseScale;
            
            const adjustedPrice = point.value + baseDrift + priceNoise;
            return { value: adjustedPrice, timestamp: point.timestamp };
        }
        
        return point;
    });
    
    // Ensure the very last point is exactly the live price
    if (history.length > 0) {
        history[history.length - 1].value = livePrice;
    }
    
    return history;
}

// Get or generate time frame history for a symbol
function getTimeFrameHistory(symbol, timeFrame) {
    // LIVE frame uses the real-time chartHistory
    if (timeFrame === 'LIVE') {
        return state.chartHistory[symbol] || [];
    }
    
    // Get current live price for smooth transition
    const livePrice = state.chartPrices[symbol] ? state.chartPrices[symbol].currentPrice : null;
    
    // Initialize cache structure if needed
    if (!state.timeFrameHistory[symbol]) {
        state.timeFrameHistory[symbol] = {};
    }
    
    // Check if we need to regenerate (cache miss or price changed significantly)
    const cached = state.timeFrameHistory[symbol][timeFrame];
    const needsRegeneration = !cached || 
        (livePrice && cached.length > 0 && 
         Math.abs(cached[cached.length - 1].value - livePrice) / livePrice > 0.001); // >0.1% change
    
    if (needsRegeneration) {
        state.timeFrameHistory[symbol][timeFrame] = generateTimeFrameHistory(symbol, timeFrame, livePrice);
    }
    
    return state.timeFrameHistory[symbol][timeFrame];
}

// Clear time frame cache for a symbol (call when switching symbols or on refresh)
function clearTimeFrameCache(symbol) {
    if (symbol) {
        delete state.timeFrameHistory[symbol];
    } else {
        state.timeFrameHistory = {};
    }
}

// Change the active time frame
function changeTimeFrame(timeFrame) {
    if (!TIME_FRAMES[timeFrame]) {
        console.error('Invalid time frame:', timeFrame);
        return;
    }
    
    const previousFrame = state.currentTimeFrame;
    state.currentTimeFrame = timeFrame;
    
    // Update UI buttons
    document.querySelectorAll('.time-frame-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.frame === timeFrame) {
            btn.classList.add('active');
        }
    });
    
    // Update the status indicator
    const status = document.getElementById('sourceStatus');
    const tf = TIME_FRAMES[timeFrame];
    
    if (timeFrame === 'LIVE') {
        status.textContent = 'LIVE';
        status.classList.add('live');
    } else {
        status.textContent = tf.label;
        status.classList.remove('live');
    }
    
    // Get history for this time frame
    const symbol = state.dataMode;
    const history = getTimeFrameHistory(symbol, timeFrame);
    
    // For non-LIVE frames, we show historical data
    // The current price and display price stay the same (from LIVE)
    // but the chart shows the time frame history
    
    // Update the chart to render with new time frame data
    // The chart will use getActiveHistory() which checks currentTimeFrame
    
    console.log(`Switched to ${timeFrame} for ${symbol}, ${history.length} points`);
}

// Get the active history based on current time frame
function getActiveHistory() {
    return getTimeFrameHistory(state.dataMode, state.currentTimeFrame);
}

// Track last processed tick per symbol to prevent duplicate processing
const lastProcessedTick = {};

// Initialize a chart for a symbol with simulated history
function initializeChart(symbol) {
    const config = stockConfig[symbol];
    const basePrice = config ? config.basePrice : 100;
    
    // Generate simulated history (uses deterministic seeded RNG)
    // This returns the history AND the final simulation state for continuity
    const result = generateSimulatedHistory(symbol, CHART_VISIBLE_POINTS);
    
    // Store in chartHistory
    state.chartHistory[symbol] = result.history;
    
    // Store prices
    const lastPrice = result.lastPrice;
    state.chartPrices[symbol] = {
        currentPrice: lastPrice,
        displayPrice: lastPrice,
        targetPrice: lastPrice
    };
    
    // Use the simulation state from history generation for continuity
    // This ensures future ticks continue from the correct state
    state.chartSimState[symbol] = result.simState;
    
    // Mark the current tick as processed so we don't immediately reprocess
    lastProcessedTick[symbol] = getCurrentTickNumber();
}

// Update price for a specific symbol (background update)
// IMPORTANT: This processes ALL missed ticks to maintain determinism
function updateSymbolPrice(symbol) {
    const config = stockConfig[symbol];
    if (!config) return;
    
    const currentTick = getCurrentTickNumber();
    const lastTick = lastProcessedTick[symbol];
    
    // Skip if we already processed this tick for this symbol
    if (lastTick === currentTick) {
        return null; // No update needed
    }
    
    // Get or create chart state for this symbol
    // Also re-initialize if lastTick is somehow undefined
    if (!state.chartPrices[symbol] || lastTick === undefined) {
        initializeChart(symbol);
        return null; // initializeChart already set up everything
    }
    
    const prices = state.chartPrices[symbol];
    const history = state.chartHistory[symbol] || [];
    let simState = state.chartSimState[symbol];
    
    if (!simState) {
        simState = createFreshSimState();
        state.chartSimState[symbol] = simState;
    }
    
    const previousPrice = prices.currentPrice;
    
    // CRITICAL: Process ALL missed ticks to maintain determinism
    // If timer skipped ticks due to browser throttling, we need to catch up
    const startTick = lastTick + 1;
    let currentPrice = prices.currentPrice;
    
    for (let tick = startTick; tick <= currentTick; tick++) {
        // Simulate this tick with its specific RNG
        currentPrice = simulatePriceForTick(symbol, simState, currentPrice, config.basePrice, tick);
        
        // Add to history
        const tickTimestamp = getTimeForTickNumber(tick);
        history.push({ value: currentPrice, timestamp: tickTimestamp });
    }
    
    // Trim history if too long
    while (history.length > 200) {
        history.shift();
    }
    
    // Mark current tick as processed
    lastProcessedTick[symbol] = currentTick;
    
    // Update prices
    prices.currentPrice = currentPrice;
    prices.targetPrice = currentPrice;
    prices.displayPrice = currentPrice;
    
    state.chartHistory[symbol] = history;
    
    return { previousPrice, newPrice: currentPrice };
}

// Simulate a single tick for a symbol - used for catching up missed ticks
// This MUST match the logic in generateSimulatedHistory exactly
function simulatePriceForTick(symbol, simState, currentPrice, basePrice, tick) {
    const cfg = simConfigCache;
    const sim = simState;
    const rng = createTickRNG(symbol, tick);
    
    // Volatility clustering - MUST match history generation exactly
    if (rng() < cfg.volatilityChangeChance) {
        if (rng() < cfg.volatilityHighEventChance) {
            sim.volatilityTarget = cfg.volatilityHighMin + rng() * (cfg.volatilityHighMax - cfg.volatilityHighMin);
        } else {
            sim.volatilityTarget = cfg.volatilityNormalMin + rng() * (cfg.volatilityNormalMax - cfg.volatilityNormalMin);
        }
    }
    sim.volatility = sim.volatility * 0.9 + sim.volatilityTarget * 0.1;
    
    // Trend - MUST match history generation exactly
    if (sim.trendDuration <= 0) {
        sim.trend = (rng() - 0.5) * 2;
        sim.trendDuration = Math.floor(rng() * 15) + 5;
    }
    sim.trendDuration--;
    
    // Get prophecy effects for this symbol at this tick's time
    const tickTime = getTimeForTickNumber(tick);
    const prophecyEffects = getProphecyEffectsForSymbol(symbol, tickTime);
    
    // Calculate price change
    const baseVolatility = currentPrice * cfg.baseVolatility;
    // Apply prophecy volatility multiplier
    const volatility = baseVolatility * sim.volatility * prophecyEffects.volatilityMultiplier;
    
    // Seeded Gaussian noise
    const gaussian = seededGaussian(rng);
    const noise = gaussian * volatility * cfg.noiseWeight;
    
    // Trend effect (natural trend, no prophecy bias)
    const trendEffect = sim.trend * volatility * cfg.trendWeight;
    
    // Mean reversion
    const deviation = (currentPrice - basePrice) / basePrice;
    const meanReversion = -deviation * currentPrice * cfg.meanReversionWeight;
    
    // Calculate natural price change
    let priceChange = noise + trendEffect + meanReversion;
    
    // Apply trend prophecy reversal logic
    // If price moves against prophecy direction, reverse it with probability
    // Check for conflicting trends first - if both up and down are active, cancel each other out
    const hasTrendUp = prophecyEffects.trendProphecies.some(p => p.type === 'trendUp');
    const hasTrendDown = prophecyEffects.trendProphecies.some(p => p.type === 'trendDown');
    
    if (hasTrendUp && hasTrendDown) {
        // Conflicting trends - cancel each other out (no reversals applied)
        // Price moves naturally without trend interference
    } else {
        // Only one direction active, or multiple same-direction - apply reversals with diminishing returns
        // No threshold - apply to ANY counter-trend movement, no matter how small
        
        // Group same-direction trends and calculate combined probability with diminishing returns
        const trendUpProphecies = prophecyEffects.trendProphecies.filter(p => p.type === 'trendUp');
        const trendDownProphecies = prophecyEffects.trendProphecies.filter(p => p.type === 'trendDown');
        
        if (trendUpProphecies.length > 0 && priceChange < 0) {
            // Any downward movement - reverse with probability
            // Calculate combined probability with diminishing returns
            // Formula: maxProbability + (1 - maxProbability) * min(0.12 * (N-1), 0.25)
            // This makes stacking less effective to encourage upgrading to higher tiers
            const maxProbability = Math.max(...trendUpProphecies.map(p => p.reversalProbability));
            const count = trendUpProphecies.length;
            const bonusMultiplier = Math.min(0.12 * (count - 1), 0.25); // Max 25% bonus
            const effectiveProbability = maxProbability + (1 - maxProbability) * bonusMultiplier;
            
            if (rng() < effectiveProbability) {
                // Reverse the movement (make it positive)
                priceChange = Math.abs(priceChange);
            }
        } else if (trendDownProphecies.length > 0 && priceChange > 0) {
            // Any upward movement - reverse with probability
            // Calculate combined probability with diminishing returns
            const maxProbability = Math.max(...trendDownProphecies.map(p => p.reversalProbability));
            const count = trendDownProphecies.length;
            const bonusMultiplier = Math.min(0.12 * (count - 1), 0.25); // Max 25% bonus
            const effectiveProbability = maxProbability + (1 - maxProbability) * bonusMultiplier;
            
            if (rng() < effectiveProbability) {
                // Reverse the movement (make it negative)
                priceChange = -Math.abs(priceChange);
            }
        }
    }
    
    // Calculate new price
    let newPrice = currentPrice + priceChange;
    
    // No artificial boundaries - prices can move freely
    // Mean reversion naturally keeps prices centered around basePrice
    
    return newPrice;
}

// Update ALL charts in background, only render active one
function updateAllCharts() {
    const now = Date.now();
    
    // Update all symbols
    Object.keys(stockConfig).forEach(symbol => {
        updateSymbolPrice(symbol);
        
        // Check for news events after price update
        if (typeof checkForNewsEvents === 'function') {
            checkForNewsEvents(symbol);
        }
    });
    
    // Sync active chart state to global state
    const activeSymbol = state.dataMode;
    if (state.chartPrices[activeSymbol]) {
        const prices = state.chartPrices[activeSymbol];
        const previousPrice = state.currentPrice;
        
        state.currentPrice = prices.currentPrice;
        state.targetPrice = prices.targetPrice;
        state.lastPriceUpdate = now;
        
        // Sync sim state
        if (state.chartSimState[activeSymbol]) {
            state.sim = state.chartSimState[activeSymbol];
        }
        
        // Add tick animation class for active chart only
        const priceEl = document.getElementById('currentPrice');
        if (priceEl) {
            const tickClass = state.currentPrice > previousPrice ? 'tick-up' : 'tick-down';
            priceEl.classList.remove('tick-up', 'tick-down');
            void priceEl.offsetWidth;
            priceEl.classList.add(tickClass);
            setTimeout(() => priceEl.classList.remove(tickClass), 150);
        }
        
        // Play chart tick sound (subtle)
        AudioManager.playTickOfChart();
        
        // Update price change percentage for active chart
        const chartPrices = state.prices;
        const changePercent = chartPrices.length > 1 
            ? ((state.currentPrice / chartPrices[chartPrices.length - 2] - 1) * 100)
            : 0;
        const changeEl = document.getElementById('priceChange');
        if (changeEl) {
            changeEl.textContent = (changePercent >= 0 ? '+' : '') + changePercent.toFixed(2) + '%';
            changeEl.className = 'price-change ' + (changePercent >= 0 ? 'up' : 'down');
        }
        
        // Trigger prediction updates when chart ticks (synchronized shrinking)
        if (typeof updatePredictions === 'function') {
            updatePredictions();
        }
    }
}

// Get prophecy effects (volatility multiplier + trend prophecies) for a specific symbol
// This is used during price simulation for each chart
// timeMs: optional timestamp in milliseconds (defaults to current time)
function getProphecyEffectsForSymbol(symbol, timeMs = null) {
    const now = timeMs !== null ? timeMs : Date.now();
    let volatilityMultiplier = 1;
    let hasSpike = false;
    let hasCalm = false;
    let spikeValue = 1;
    let calmValue = 1;
    const trendProphecies = []; // Array of { type: 'trendUp'|'trendDown', reversalProbability: number }
    
    if (!state.deals) return { volatilityMultiplier, trendProphecies };
    
    state.deals.forEach(prophecy => {
        if (prophecy.resolved || prophecy.targetStock !== symbol || !prophecy.isDecoded) return;
        
        const elapsed = (now - prophecy.startTime) / 1000;
        const remaining = Math.max(0, prophecy.duration - elapsed);
        if (remaining <= 0) return;
        
        // Trend prophecies - store for reversal logic
        if (prophecy.prophecyType === 'trendUp' || prophecy.prophecyType === 'trendDown') {
            const reversalProbability = prophecy.reversalProbability || 0.15; // Default fallback
            trendProphecies.push({
                type: prophecy.prophecyType,
                reversalProbability: reversalProbability
            });
        }
        // Volatility prophecies - only active during their time window
        else if (prophecy.prophecyType === 'volatilitySpike') {
            // Check if we're in the active window
            const inWindow = elapsed >= (prophecy.windowStart || 0) && elapsed <= (prophecy.windowEnd || prophecy.duration);
            if (inWindow) {
                hasSpike = true;
                spikeValue = Math.max(spikeValue, prophecy.trueVolatility);
            }
        } else if (prophecy.prophecyType === 'volatilityCalm') {
            // Check if we're in the active window
            const inWindow = elapsed >= (prophecy.windowStart || 0) && elapsed <= (prophecy.windowEnd || prophecy.duration);
            if (inWindow) {
                hasCalm = true;
                calmValue = Math.min(calmValue, prophecy.trueVolatility);
            }
        }
    });
    
    // Apply volatility multipliers - spike takes priority over calm
    if (hasSpike) {
        volatilityMultiplier = spikeValue;
    } else if (hasCalm) {
        volatilityMultiplier = calmValue;
    }
    
    return { volatilityMultiplier, trendProphecies };
}

// Legacy wrapper for volatility only
function getVolatilityMultiplierForSymbol(symbol) {
    return getProphecyEffectsForSymbol(symbol).volatilityMultiplier;
}

// Legacy wrapper - no longer used but kept for compatibility
function getTrendBiasForSymbol(symbol) {
    return 0; // Trend prophecies now use reversal logic instead
}

// Calculate all prophecy effects for current stock
function calculateProphecyEffects() {
    const now = Date.now();
    const effects = {
        trendBias: 0,
        lowerShore: null,
        upperShore: null,
        inevitableZones: [],
        volatilityMultiplier: 1,
        activeProphecyCount: 0
    };
    
    state.deals.forEach(prophecy => {
        if (prophecy.resolved || prophecy.targetStock !== state.dataMode || !prophecy.isDecoded) return;
        
        const elapsed = (now - prophecy.startTime) / 1000;
        const remaining = Math.max(0, prophecy.duration - elapsed);
        if (remaining <= 0) return;
        
        effects.activeProphecyCount++;
        const timeWeight = remaining / prophecy.duration;
        
        switch (prophecy.prophecyType) {
            case 'trendUp':
            case 'trendDown': {
                // Trend prophecies now use reversal logic in price simulation
                // No post-simulation effects needed
                break;
            }
            case 'shore': {
                // Combined shore - sets both lower and upper bounds
                const lowerShore = prophecy.lowerShore;
                const upperShore = prophecy.upperShore;
                
                // Use most restrictive values (highest floor, lowest ceiling)
                if (!effects.lowerShore || lowerShore > effects.lowerShore) {
                    effects.lowerShore = lowerShore;
                }
                if (!effects.upperShore || upperShore < effects.upperShore) {
                    effects.upperShore = upperShore;
                }
                break;
            }
            case 'inevitableZone': {
                effects.inevitableZones.push({
                    target: prophecy.trueValue,
                    remaining: remaining,
                    duration: prophecy.duration,
                    prophecy: prophecy
                });
                break;
            }
            case 'volatilitySpike': {
                // Active immediately when decoded
                effects.volatilityMultiplier = Math.max(effects.volatilityMultiplier, prophecy.trueVolatility);
                break;
            }
            case 'volatilityCalm': {
                // Active immediately when decoded
                effects.volatilityMultiplier = Math.min(effects.volatilityMultiplier, prophecy.trueVolatility);
                break;
            }
        }
    });
    
    // Trend bias is no longer used (trend prophecies use reversal logic)
    // Keep trendBias in return for backwards compatibility but it's always 0
    
    return effects;
}

// Price simulation - generates new target price
// Main price update function - updates ALL charts in background
function updatePrice() {
    // Update all charts in background
    updateAllCharts();
    
    // Apply prophecy effects to active chart only
    applyProphecyEffectsToActiveChart();
}

// Apply prophecy effects (shores, zones) to the currently active chart
function applyProphecyEffectsToActiveChart() {
    const prophecyEffects = calculateProphecyEffects();
    const activeSymbol = state.dataMode;
    
    if (!state.chartPrices[activeSymbol]) return;
    
    let currentPrice = state.chartPrices[activeSymbol].currentPrice;
    let modified = false;
    
    // Apply combined shore constraints (enforce floor/ceiling together)
    // When both shores are active, they work together as a combined range
    // Use seeded RNG for determinism
    const currentTick = getCurrentTickNumber();
    const rng = createTickRNG(activeSymbol + '_prophecy', currentTick);
    
    // Combine shores: if both are active, clamp price to the range
    if (prophecyEffects.lowerShore !== null && prophecyEffects.upperShore !== null) {
        // Both shores active - combine them into a single range constraint
        const lowerBound = prophecyEffects.lowerShore;
        const upperBound = prophecyEffects.upperShore;
        
        if (currentPrice < lowerBound) {
            // Below lower bound - clamp to lower bound with small random offset
            currentPrice = lowerBound + rng() * currentPrice * 0.001;
            modified = true;
        } else if (currentPrice > upperBound) {
            // Above upper bound - clamp to upper bound with small random offset
            currentPrice = upperBound - rng() * currentPrice * 0.001;
            modified = true;
        }
        // If price is within bounds, no modification needed
    } else {
        // Only one shore active - apply individually
        if (prophecyEffects.lowerShore !== null && currentPrice < prophecyEffects.lowerShore) {
            currentPrice = prophecyEffects.lowerShore + rng() * currentPrice * 0.001;
            modified = true;
        }
        if (prophecyEffects.upperShore !== null && currentPrice > prophecyEffects.upperShore) {
            currentPrice = prophecyEffects.upperShore - rng() * currentPrice * 0.001;
            modified = true;
        }
    }
    
    // Apply inevitable zone magnetism
    // If shore bounds are active, clamp zone targets to within bounds to prevent conflicts
    const lowerBound = prophecyEffects.lowerShore;
    const upperBound = prophecyEffects.upperShore;
    const hasShoreBounds = lowerBound !== null && upperBound !== null;
    
    prophecyEffects.inevitableZones.forEach(zone => {
        if (!zone.prophecy.touched) {
            // If shore bounds exist and zone target is outside, clamp target to nearest bound
            let effectiveTarget = zone.target;
            if (hasShoreBounds) {
                if (zone.target < lowerBound) {
                    effectiveTarget = lowerBound; // Clamp to lower bound
                } else if (zone.target > upperBound) {
                    effectiveTarget = upperBound; // Clamp to upper bound
                }
            }
            
            const distanceToZone = effectiveTarget - currentPrice;
            const urgency = 1 - (zone.remaining / zone.duration);
            // Use magnetism strength from prophecy config (default 0.25)
            const magnetismStrength = zone.prophecy.magnetismStrength || 0.25;
            // Stronger pull that increases with urgency
            const pullStrength = urgency * urgency * magnetismStrength;
            currentPrice += distanceToZone * pullStrength;
            modified = true;
            
            // Check if price is within the actual interval bounds
            const intervalMin = zone.prophecy.intervalMin;
            const intervalMax = zone.prophecy.intervalMax;
            if (currentPrice >= intervalMin && currentPrice <= intervalMax) {
                zone.prophecy.touched = true;
            }
        }
    });
    
    // Update if modified
    if (modified) {
        state.chartPrices[activeSymbol].currentPrice = currentPrice;
        state.chartPrices[activeSymbol].targetPrice = currentPrice;
        state.currentPrice = currentPrice;
        state.targetPrice = currentPrice;
        
        // Update last history point
        const history = state.chartHistory[activeSymbol];
        if (history && history.length > 0) {
            history[history.length - 1].value = currentPrice;
        }
    }
}

// Initialize game systems (called when Fortune Trader app is launched)
function initGameSystems() {
    // Game state already loaded in initHub
    const hasLoadedSave = state.balance > 0 || state.purchasedUpgrades.length > 0;
    
    // Populate stock selector dropdown from config
    const sourceSelect = document.getElementById('sourceSelect');
    sourceSelect.innerHTML = '';
    
    const initialSymbol = Object.keys(stockConfig)[0]; // First stock in config
    
    Object.keys(stockConfig).forEach(key => {
        const config = stockConfig[key];
        const option = document.createElement('option');
        option.value = key;
        option.textContent = config.name;
        if (key === initialSymbol) {
            option.selected = true;
        }
        sourceSelect.appendChild(option);
    });
    
    // Setup canvas
    initChart();
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Initialize ALL charts with simulated history
    console.log('Initializing all charts with simulated history...');
    Object.keys(stockConfig).forEach(symbol => {
        initializeChart(symbol);
        console.log(`Initialized chart for ${symbol}`);
    });
    
    // Ensure chart data is properly loaded for initial symbol
    if (!state.chartHistory[initialSymbol] || state.chartHistory[initialSymbol].length === 0) {
        console.warn(`No chart history for ${initialSymbol}, re-initializing...`);
        initializeChart(initialSymbol);
    }
    
    state.displayBalance = state.balance;
    
    // Start game loops - updatePrice now updates ALL charts
    setInterval(updatePrice, 2000); // Update all charts every 2 seconds
    setInterval(updateDeals, 1000);
    setInterval(updatePositions, 1000);
    setInterval(() => {
        if (typeof updateMarginPosition === 'function') {
            updateMarginPosition();
        }
    }, 2000); // Update margin position every 2 seconds (on tick)
    // Execute bots after price updates (every 2 seconds)
    setInterval(() => {
        if (typeof executeBots === 'function') {
            executeBots();
        }
    }, 2000);
    // updatePredictions is now called from updateAllCharts when chart ticks (synchronized)
    
    // Auto-save every 30 seconds
    setInterval(autoSave, 30000);
    
    // Use changeDataSource to properly set up the initial stock display
    // This ensures all state is synced correctly and chart is rendered
    changeDataSource(initialSymbol);
    
    // Start smooth animation loop (only renders active chart)
    smoothAnimationLoop();
    updateBalanceDisplay();
    updateComboCounter();
    
    // Initialize cookie inventory display
    renderCookieInventory();
    
    // Render shop items from config
    renderShopItems();
    
    // Render purchased upgrades in navbar
    renderPurchasedUpgrades();
    
    // Update cookie tier prices from config
    updateCookieTierPrices();
    
    // Update shop item states if we loaded upgrades
    if (hasLoadedSave) {
        updateShopItemStates();
    }
    
    // Re-render UI elements for initial stock
    renderDeals();
    renderPositions();
    renderStockHolding();
    if (typeof renderMarginPosition === 'function') {
        renderMarginPosition();
    }
    // Update button states on init
    updateBetLockButtons();
    
    // Initialize news system
    if (typeof initNewsSystem === 'function') {
        initNewsSystem();
    }
    
    // Update tab and button lock states
    if (typeof updateTabLockStates === 'function') {
        updateTabLockStates();
    }
    updateBetLockButtons();
    
    console.log('All charts initialized and running in background');
}

// Initialize the application (hub first)
function initApp() {
    initVersionStamp();
    initAudioControls();
    initButtonClickSounds();
    // Initialize the hub/phone interface first
    initHub();
    console.log('Hub initialized - waiting for app selection');
}

// Start the app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    // DOM already loaded
    initApp();
}
